import axios from "../axios-users";
import React from "react";
import * as actionTypes from "./types";

//Register User

export const editUser = userData => async dispatch => {
  await axios
    .post("/accounts/settings", userData, {
      headers: {
        token: localStorage.jwtToken
      }
    })
    .then(async res => {
      console.log("token:" + axios.defaults.headers.common.Authorization);
      console.log("[from edit profile LAZZZZ]", { ...res });
      dispatch(editProfileUser(res.data));
      console.log("hjbjkj", { ...res });
      await axios
        .get("/users/show", {
          params: {
            user_ID: res.data._id
          }
        })
        .then(res => {
          console.log("MEN EL update ", res);
          const user = res.data.user;
          dispatch(setCurrentUser(user, user));
        });
    })
    .catch(err => {
      console.log("{hello}", err.response.data);
      dispatch({
        type: actionTypes.GET_ERRORS,
        payload: err.response.data
      });
    });

  return Promise.resolve();
};

export const editImage = userData => async dispatch => {
  //console.log("{image}", userData);
  await axios
    .post("/accounts/update_profile_image ", userData, {
      headers: {
        token: localStorage.jwtToken
      }
    })
    .then(async res => {
      console.log("h", { ...res });
      dispatch(editImageUser(res.data));
      await axios
        .get("/users/show", {
          params: {
            user_ID: res.data._id
          }
        })
        .then(res => {
          console.log("MEN EL image ", res);
          const user = res.data.user;
          dispatch(setCurrentUser(user, user));
        });
    })
    .catch(err => {
      console.log("{hello}", err.response.data);
      dispatch({
        type: actionTypes.GET_ERRORS,
        payload: err.response.data
      });
    });
  return Promise.resolve();
};

// export const getProfile = screen_name => dispatch => {
//   return dispatch => {
//     axios
//       .get("/accounts/settings", {
//         params: {
//           screen_name
//         }
//       })
//       .then(response => {
//         dispatch(setProfileUser(response.data));
//       })
//       .catch(error => {});
//   };
// };

export const editProfileUser = currentUser => {
  return {
    type: actionTypes.EDIT_PROFILE,
    payload: {
      profile: currentUser
    }
  };
};

export const editImageUser = currentImage => {
  return {
    type: actionTypes.SET_PROFILE_IMAGE,
    payload: {
      image: currentImage
    }
  };
};

// export const setProfileUser = currentUser => {
//   return {
//     type: actionTypes.SET_PROFILE,
//     payload: {
//       profile: currentUser
//     }
//   };
//};

export const setCurrentUser = (profile, authUser) => {
  return {
    type: actionTypes.SET_CURRENT_USER,
    payload: {
      profile: profile,
      authUser: authUser
    }
  };
};
